Put repository banners, icons and other static assets here.
