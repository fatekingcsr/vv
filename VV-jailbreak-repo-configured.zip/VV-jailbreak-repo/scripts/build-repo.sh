#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
mkdir -p debs
dpkg-scanpackages -m debs /dev/null > Packages
if [ -s Packages ]; then
  xz -9 -c Packages > Packages.xz
  bzip2 -9 -c Packages > Packages.bz2
else
  : > Packages.xz
  : > Packages.bz2
fi

cat > Release <<EOF
Origin: VV
Label: VV
Suite: stable
Codename: stable
Architectures: iphoneos-arm iphoneos-arm64 iphoneos-arm64e all
Components: main
Description: VV Jailbreak Repository
Date: $(LC_ALL=C date -u '+%a, %d %b %Y %H:%M:%S %Z')
EOF

for section in MD5Sum SHA256 SHA512; do
  echo "$section:" >> Release
  case "$section" in
    MD5Sum) hashcmd=md5sum ;;
    SHA256) hashcmd=sha256sum ;;
    SHA512) hashcmd=sha512sum ;;
  esac
  for f in Packages Packages.xz Packages.bz2; do
    if [ -f "$f" ]; then
      hash=$($hashcmd "$f" | awk '{print $1}')
      size=$(wc -c < "$f" | tr -d ' ')
      echo " $hash $size $f" >> Release
    fi
  done
done

python3 scripts/generate-catalog.py
echo "Repository metadata generated."
