#!/usr/bin/env python3
import json, os, re
from pathlib import Path
p=Path("Packages")
text=p.read_text(errors="replace") if p.exists() else ""
items=[]
for block in re.split(r"\n\s*\n", text.strip()):
    d={}
    for line in block.splitlines():
        if ": " in line:
            k,v=line.split(": ",1); d[k]=v
    if d:
        fn=d.get("Filename","")
        if fn:
            fn="./"+fn.lstrip("./")
        items.append({
            "package": d.get("Package",""),
            "name": d.get("Name",d.get("Package","")),
            "version": d.get("Version",""),
            "architecture": d.get("Architecture",""),
            "description": d.get("Description",""),
            "filename": fn,
            "icon": d.get("Icon",""),
            "depiction": d.get("Depiction",""),
            "sileoDepiction": d.get("SileoDepiction","")
        })
Path("packages.json").write_text(json.dumps(items,ensure_ascii=False,indent=2)+"\n")
print(f"Catalog: {len(items)} package(s)")
