#!/bin/bash
set -e
shopt -s nullglob
debs=(debs/*.deb)
if [ ${#debs[@]} -eq 0 ]; then
  echo "No .deb files found in debs/ (template is empty)."
  exit 0
fi
for deb in "${debs[@]}"; do
  echo "Checking $deb"
  dpkg-deb -I "$deb" >/dev/null
done
echo "All Debian packages passed validation."
